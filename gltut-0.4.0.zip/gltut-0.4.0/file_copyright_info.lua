

copywriteText = "Copyright (C) 2010-2012 by Jason L. McKesson";
licenseText = "This file is licensed under the MIT License."
