
dofile("../framework/framework.lua")

SetupSolution("Test")
SetupProject("Test", "test.cpp")
