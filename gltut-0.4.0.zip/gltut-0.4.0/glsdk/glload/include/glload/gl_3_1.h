#ifndef OPENGL_GEN_3_1_H
#define OPENGL_GEN_3_1_H

#include "_int_gl_type.h"
#include "_int_gl_exts.h"

#include "_int_gl_1_0.h"
#include "_int_gl_1_1.h"
#include "_int_gl_1_2.h"
#include "_int_gl_1_3.h"
#include "_int_gl_1_4.h"
#include "_int_gl_1_5.h"
#include "_int_gl_2_0.h"
#include "_int_gl_2_1.h"
#include "_int_gl_3_0.h"
#include "_int_gl_3_1.h"
#endif /*OPENGL_GEN_3_1_H*/
